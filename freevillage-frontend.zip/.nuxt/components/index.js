export { default as HeaderType01 } from '../..\\components\\headerType01.vue'
export { default as InputRegion } from '../..\\components\\inputRegion.vue'
export { default as Navigation } from '../..\\components\\navigation.vue'
export { default as Quicks } from '../..\\components\\quicks.vue'
export { default as FormInputAddress } from '../..\\components\\form\\inputAddress.vue'
export { default as FormInputImgs } from '../..\\components\\form\\inputImgs.vue'
export { default as FormPostsInputCamera } from '../..\\components\\form\\posts\\inputCamera.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
